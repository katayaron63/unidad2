/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

/**
 *
 * @author katay
 */
public class Conexion {
      private final String driver;
    private final String url;
    private final String usuario;
    private final String password;
    
      public Conexion () {
        this.driver = "com.MYSQL.JBDC.Driver";
        this.url = "jdbc:mysql://localhost:3306/bd_cliente?zeroDateTimeBehavior=CONVERT_TO_NULL ";
        this.usuario = "root";
        this.password = "";
        
    }
      public String getDriver() {
        return driver;
    }

    public String getUrl() {
        return url;
    }

    public String getUsuario() {
        return usuario;
    }

    public String getPassword() {
        return password;
    }

}
